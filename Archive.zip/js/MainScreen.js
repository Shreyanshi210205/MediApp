window.addEventListener("load", function () {
  this.localStorage.clear("cart");
  fetchDetails()
    .then((body) => {
      this.localStorage.setItem("products", JSON.stringify(body));
    })
    .then(
      () => (products = [...JSON.parse(this.localStorage.getItem("products"))])
    )
    .then(() => console.log(products));
  this.localStorage.removeItem("cart");
});
let products = [];
let basket = JSON.parse(localStorage.getItem("cart")) || [];

async function fetchDetails() {
  let url = "http://demo-env.eba-uqr6mfaq.us-east-1.elasticbeanstalk.com/api/getAllProducts"
  let response = await fetch("http://demo-env.eba-uqr6mfaq.us-east-1.elasticbeanstalk.com/api/getAllProducts", {
    method: 'get',
    headers: {
      "Content-Type": "application/json",
      // 'Content-Type': 'application/x-www-form-urlencoded',
    },
  });
  let body = await response.json();

  if (response.status == 200) {
    showAllProducts(body);
  }
  return body;
}

let showAllProducts = (products) => {
  return products.map((product) => {
    const productsContainer = document.getElementById("productsContainer");
    const singleProduct = document.createElement("article");
    singleProduct.classList.add("card");

    let {
      productId,
      productName,
      productPictureMain,
      productPictureOne,
      productPictureTwo,
      productPictureThree,
      productPictureFour,
      productPictureFive,
      productPrice,
      productInfoOne,
      productInfoTwo,
      productInfoThree,
      productInfoUsageDetails,
    } = product;

    singleProduct.innerHTML = `<figure>
            <img src="${productPictureMain}" alt="" />
          </figure>
          <div class="cardInfo">
            <div class="cardHeading">
              <h6>${productName}</h6>
            </div>
            <div class="cardPrice">
              <div class="prespcription">
                <i class="fa-solid fa-prescription-bottle-medical"></i>
                <p>Prescription required</p>
              </div>
              <div class="cardActualPrice">
                <span>EUR ${productPrice}</span>
              </div>
              <div class="cardDelivery">
                <p>Get it in <span>1 Day</span></p>
              </div>
            </div>
            <div class="cardButtons">
              <a style="cursor:pointer"id="${productId}" onclick="setValueLocalStorage(this)">View Details</a>
              <div class="addToCart">
                <button type="button" class="addToCartButton" onClick="addToCart(this)" id="${productId}">
                  <div class="addToCartText" >
                    <i class="fa-solid fa-plus"></i>
                    <span>Add</span>
                  </div>
                </button>
                <div class="counter" id="${productId}">
                  <button type="button" id="decreaseItemButton" onclick="decrease(this)"><i class="fa-solid fa-minus"></i></button>
                  <input type="text" value="1" readonly class="itemQuantity"/>
                  <button type="button" id="increaseItemButton" onclick="increase(this)"><i class="fa-solid fa-plus"></i></button>
                </div>
              </div>
            </div>
          </div>`;

    productsContainer.append(singleProduct);
  });
};

async function addToCart(el) {
  let id = el.getAttribute("id");
  let notyf = new Notyf();
  let product = products.find((item) => item.productId.toString() === id);
  let {
    productId,
    productName,
    productPictureMain,
    productPictureOne,
    productPictureTwo,
    productPictureThree,
    productPictureFour,
    productPictureFive,
    productPrice,
    productInfoOne,
    productInfoTwo,
    productInfoThree,
    productInfoUsageDetails,
  } = product;
  const counterAllContainer = document.querySelectorAll(".counter");
  counterAllContainer.forEach((element) => {
    if (element.getAttribute("id") === id) {
      checkCartTotalItems();
      element.style.display = "grid";
      el.style.display = "none";
      notyf.success("Items added to the cart");
      basket.push({
        productId,
        productName,
        productPictureMain,
        productPictureOne,
        productPictureTwo,
        productPictureThree,
        productPictureFour,
        productPictureFive,
        productPrice,
        productInfoOne,
        productInfoTwo,
        productInfoThree,
        productInfoUsageDetails,
        item: 1,
        sum: productPrice,
      });
      localStorage.setItem("cart", JSON.stringify(basket));
    }
  });
}

function checkCartTotalItems(el) {
  let cartItemsQuantity = document.getElementById("cartItemsQuantity");

  cartItemsQuantity.style.display = "grid";
  let count = cartItemsQuantity.innerText;
  if (count === "") {
    cartItemsQuantity.innerText = "1";
  } else {
    if (el === "inc") {
      count = parseInt(count) + 1;
      cartItemsQuantity.innerText = count.toString();
    } else if (el === "desc") {
      count = parseInt(count) - 1;
      cartItemsQuantity.innerText = count.toString();
    } else if (el === "zero") {
      count = parseInt(count) - 1;
      cartItemsQuantity.innerText = count.toString();
    } else {
      count = parseInt(count) + 1;
      cartItemsQuantity.innerText = count.toString();
    }
  }
}

async function increase(el) {
  let inputValue = el.previousElementSibling;
  let id = el.parentElement.id;
  let count = parseInt(inputValue.getAttribute("value"));
  count = count + 1;
  inputValue.setAttribute("value", count.toString());
  checkCartTotalItems("inc");
  let search = basket.find((x) => x.productId.toString() === id);
  search.item = count;
  search.sum = count * search.productPrice;
  localStorage.setItem("cart", JSON.stringify(basket));
}

async function decrease(el) {
  let inputValue = el.nextElementSibling;
  let count = parseInt(inputValue.getAttribute("value"));
  let notyf = new Notyf();
  let id = el.parentElement.id;
  count = count - 1;
  let search = basket.find((x) => x.productId.toString() === id);
  if (count < 1) {
    let addtocartDiv = el.parentElement.previousElementSibling;
    addtocartDiv.style.display = "grid";
    el.parentElement.style.display = "none";
    notyf.error("item Removed from the cart");
    checkCartTotalItems("zero");
    search.sum = count * search.sum;
    search.item = count;
    basket.pop(search);
    localStorage.setItem("cart", JSON.stringify(basket));
  } else {
    inputValue.setAttribute("value", count.toString());
    checkCartTotalItems("desc");
    search.item = count;
    search.sum = count * search.productPrice;
    localStorage.setItem("cart", JSON.stringify(basket));
  }
}

function setValueLocalStorage(el) {
  el.style.cursor = "pointer";
  //alert("setting value", el.getAttribute("id"));
  localStorage.setItem("productId", el.getAttribute("id"));
  window.location = "./Description.html";
}

let bookAppointment = document.getElementById(
  "bookapp"
);

bookAppointment.addEventListener("click", function () {
  location.href = "/appointment.html";
});
